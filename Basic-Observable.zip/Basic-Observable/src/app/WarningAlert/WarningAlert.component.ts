import { Component } from '@angular/core';

@Component({
    selector: 'app-WarningAlert',
    templateUrl: './WarningAlert.component.html'
})
export class WarningAlertComponent {

}