import { Component } from '@angular/core';

@Component({
    selector: 'app-SuccessAlert',
    templateUrl: './SuccessAlert.component.html'
})
export class SuccessAlertComponent{

}