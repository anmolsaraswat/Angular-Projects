import {Recipe} from './recipe.model'
import { EventEmitter } from '@angular/core';
import { Ingredient } from '../shared/ingredient.model';
export class RecipeService{
    recipeSelected = new EventEmitter<Recipe>();
    private recipes: Recipe[] = [
        new Recipe('A test Recipe', 'This is a simply a test','asdv', [
            new Ingredient('Meat' , 1),
            new Ingredient('French Fries' , 20)
        ]),
        new Recipe('A test Recipe2', 'This is a simply a test2','asdv2',[
            new Ingredient('Buns', 2),
            new Ingredient('Meat', 1)
        ])];

    getRecipes(){
        return this.recipes.slice(); // We are only accessing the copy of the array from outside.
    }
    
    addIngredientsToShoppingList(ingredients: Ingredient[]){
        
    }
}