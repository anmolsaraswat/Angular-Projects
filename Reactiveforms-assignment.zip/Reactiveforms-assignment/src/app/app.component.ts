import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'assignment-reactiveforms';
  myForm :FormGroup;
  forbiddenProjectName = 'test';

  ngOnInit(){
    this.myForm = new FormGroup({
      'projectName' : new FormControl(null, Validators.required, this.forbiddenProjecName),
      'email' : new FormControl(null, [Validators.email, Validators.required]),
      'projectStatus' : new FormControl(null)
    })
  }

  onSubmit(){
    console.log(this.myForm);
  }

  // forbiddenProjecName(control: FormControl) : {[s: string] : boolean}{
  //   if(this.forbiddenProjectName  === control.value){
  //     return {'ProjectnameIsForbidden': true};
  //   }
  //   return null;
  // }

  forbiddenProjecName(control: FormControl): Promise<any> | Observable<any>{
    const promise = new Promise<any>((resolve, reject) =>{
      setTimeout(() => {
        if(control.value == 'test'){
          resolve({'ProjectnameIsForbidden' : true});
        } else {
          resolve(null);
        }
      }, 1500);
    });
    return promise;
  }
}
