export class CounterService{
    countatoia = 0;
    countiatoa = 0;

    incrementCounteratoia()
    {
        this.countatoia++;
        console.log('Active to Inactive Count:' + this.countatoia);
    }
    incrementCounteriatoa()
    {
        this.countiatoa++;
        console.log('Inactive to Active Count:' + this.countiatoa);
    }
}